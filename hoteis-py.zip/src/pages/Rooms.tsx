import React, { useState } from 'react';
import { Plus, Filter, Search } from 'lucide-react';
import RoomCard from '../components/rooms/RoomCard';

// Mock data for rooms
const roomsData = [
  {
    id: 101,
    type: 'Standard',
    beds: 'Queen',
    capacity: 2,
    price: 120,
    status: 'occupied',
    guest: 'John Smith',
    checkIn: '2023-06-12',
    checkOut: '2023-06-15',
    features: ['Wi-Fi', 'TV', 'AC', 'Breakfast']
  },
  {
    id: 102,
    type: 'Standard',
    beds: 'Twin',
    capacity: 2,
    price: 120,
    status: 'available',
    guest: null,
    checkIn: null,
    checkOut: null,
    features: ['Wi-Fi', 'TV', 'AC']
  },
  {
    id: 103,
    type: 'Deluxe',
    beds: 'King',
    capacity: 2,
    price: 180,
    status: 'cleaning',
    guest: null,
    checkIn: null,
    checkOut: null,
    features: ['Wi-Fi', 'TV', 'AC', 'Minibar', 'Breakfast']
  },
  {
    id: 104,
    type: 'Deluxe',
    beds: 'Queen',
    capacity: 2,
    price: 160,
    status: 'occupied',
    guest: 'Emma Wilson',
    checkIn: '2023-06-14',
    checkOut: '2023-06-18',
    features: ['Wi-Fi', 'TV', 'AC', 'Minibar', 'Breakfast']
  },
  {
    id: 105,
    type: 'Suite',
    beds: 'King',
    capacity: 3,
    price: 250,
    status: 'maintenance',
    guest: null,
    checkIn: null,
    checkOut: null,
    features: ['Wi-Fi', 'TV', 'AC', 'Minibar', 'Living Area', 'Breakfast']
  },
  {
    id: 106,
    type: 'Standard',
    beds: 'Queen',
    capacity: 2,
    price: 120,
    status: 'available',
    guest: null,
    checkIn: null,
    checkOut: null,
    features: ['Wi-Fi', 'TV', 'AC']
  },
  {
    id: 201,
    type: 'Premium',
    beds: 'King',
    capacity: 2,
    price: 220,
    status: 'occupied',
    guest: 'Michael Brown',
    checkIn: '2023-06-15',
    checkOut: '2023-06-20',
    features: ['Wi-Fi', 'TV', 'AC', 'Minibar', 'Balcony', 'Breakfast']
  },
  {
    id: 202,
    type: 'Deluxe',
    beds: 'Twin',
    capacity: 2,
    price: 160,
    status: 'reserved',
    guest: 'Olivia Johnson',
    checkIn: '2023-06-16',
    checkOut: '2023-06-19',
    features: ['Wi-Fi', 'TV', 'AC', 'Minibar', 'Breakfast']
  }
];

const Rooms: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');

  // Filter rooms based on search query and filters
  const filteredRooms = roomsData.filter(room => {
    // Search filter
    const searchMatches = 
      room.id.toString().includes(searchQuery) || 
      room.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (room.guest && room.guest.toLowerCase().includes(searchQuery.toLowerCase()));
    
    // Status filter
    const statusMatches = statusFilter === 'all' || room.status === statusFilter;
    
    // Type filter
    const typeMatches = typeFilter === 'all' || room.type === typeFilter;
    
    return searchMatches && statusMatches && typeMatches;
  });

  // Count rooms by status
  const roomCounts = {
    all: roomsData.length,
    available: roomsData.filter(room => room.status === 'available').length,
    occupied: roomsData.filter(room => room.status === 'occupied').length,
    reserved: roomsData.filter(room => room.status === 'reserved').length,
    cleaning: roomsData.filter(room => room.status === 'cleaning').length,
    maintenance: roomsData.filter(room => room.status === 'maintenance').length,
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <h1 className="text-3xl font-bold text-white">Room Management</h1>
        <button className="btn-primary flex items-center">
          <Plus size={18} className="mr-2" />
          Add New Room
        </button>
      </div>

      <div className="flex flex-wrap gap-3 bg-slate-800 rounded-lg p-4">
        <button 
          onClick={() => setStatusFilter('all')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            statusFilter === 'all' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-700'
          }`}
        >
          All ({roomCounts.all})
        </button>
        <button 
          onClick={() => setStatusFilter('available')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            statusFilter === 'available' ? 'bg-green-600 text-white' : 'text-slate-300 hover:bg-slate-700'
          }`}
        >
          Available ({roomCounts.available})
        </button>
        <button 
          onClick={() => setStatusFilter('occupied')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            statusFilter === 'occupied' ? 'bg-red-600 text-white' : 'text-slate-300 hover:bg-slate-700'
          }`}
        >
          Occupied ({roomCounts.occupied})
        </button>
        <button 
          onClick={() => setStatusFilter('reserved')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            statusFilter === 'reserved' ? 'bg-yellow-600 text-white' : 'text-slate-300 hover:bg-slate-700'
          }`}
        >
          Reserved ({roomCounts.reserved})
        </button>
        <button 
          onClick={() => setStatusFilter('cleaning')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            statusFilter === 'cleaning' ? 'bg-purple-600 text-white' : 'text-slate-300 hover:bg-slate-700'
          }`}
        >
          Cleaning ({roomCounts.cleaning})
        </button>
        <button 
          onClick={() => setStatusFilter('maintenance')}
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
            statusFilter === 'maintenance' ? 'bg-gray-600 text-white' : 'text-slate-300 hover:bg-slate-700'
          }`}
        >
          Maintenance ({roomCounts.maintenance})
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by room number, type, or guest name..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5"
          />
        </div>
        
        <div className="flex gap-4">
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="pl-10 pr-8 py-2.5 appearance-none"
            >
              <option value="all">All Types</option>
              <option value="Standard">Standard</option>
              <option value="Deluxe">Deluxe</option>
              <option value="Premium">Premium</option>
              <option value="Suite">Suite</option>
            </select>
          </div>
        </div>
      </div>

      {filteredRooms.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 bg-slate-800 rounded-lg">
          <div className="text-slate-400 mb-4">
            <Search size={48} />
          </div>
          <h3 className="text-xl font-medium mb-2">No Rooms Found</h3>
          <p className="text-slate-400 text-center max-w-md">
            No rooms match your current search criteria. Try adjusting your filters or search query.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredRooms.map(room => (
            <RoomCard key={room.id} room={room} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Rooms;